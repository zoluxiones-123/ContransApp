package com.contrans.app.Util;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;

// import com.kulzen.lymtaxi.pasajero.R;
// import com.kulzen.lymtaxi.pasajero.WebServiceInfo;

import com.contrans.app.R;
//import com.loopj.android.http.AsyncHttpClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by carlo on 08/11/2017.
 */

public class ActBase extends AppCompatActivity {

    protected String _ActCode;
    protected AppCompatActivity _ActividadActual;
    protected String[] permisosActividad;
    //protected List<String> permisosActividad;

    protected WebServiceInfo _WSInfo = null;
    protected WebServiceInfo _RestApiInfo = null;

    // protected AsyncHttpClient _HttpClient = null;
    public Retrofit _Retrofit;

    public Retrofit getRetrofitContrans() {
        if (_Retrofit == null) {
            //Defining the Retrofit using Builder
            _Retrofit = HttpUtils.getRetrofitClient(_RestApiInfo.getBaseUrl());
        }
        return _Retrofit;
    }


    public ActBase(){
        super();
        _ActCode = "0";
        _ActividadActual = this;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        inicializarPostCreate();
    }

    void inicializarPostCreate(){
        _RestApiInfo = new WebServiceInfo();
        _RestApiInfo.setBaseUrl(getString(R.string.rest_api_url_contrans));

        //_HttpClient = new AsyncHttpClient();

        /*_WSInfo = new WebServiceInfo();
        _WSInfo.setNameSpace(getString(R.string.ws_namespace_contrans));
        _WSInfo.setBaseUrl(getString(R.string.ws_url_contrans));*/
    }




    protected String[] verificarPermisosPendientes() {
        List<String> permisosPendientes = new ArrayList<String>();

        if(permisosActividad != null)
            for(String p : permisosActividad)
                if(ContextCompat.checkSelfPermission(_ActividadActual, p) != PackageManager.PERMISSION_GRANTED) // Permiso OK
                    permisosPendientes.add(p);

        return permisosPendientes.toArray(new String[0]); // Conversión a Array String
    }

    protected void solicitarPermiso(String[] permisos, int codigoPeticion){
        ActivityCompat.requestPermissions(
                _ActividadActual,
                permisos,
                codigoPeticion);
    }

    protected void solicitarPermisoPendientes(int codigoPeticion){
        try{
            String[] permisosPendientes = verificarPermisosPendientes();
            if(permisosPendientes.length > 0)
                solicitarPermiso(permisosPendientes, codigoPeticion);
        }catch (Exception e){

        }
    }



}

