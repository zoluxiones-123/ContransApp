
package com.contrans.app.Util;

import android.app.Activity;
import android.util.Log;
import android.widget.Toast;



/**
 * Created by carlo on 12/11/2019.
 */

public class Util {
    public static void mostrarMensaje(Activity activity, String text) {
        Toast.makeText(activity, text, Toast.LENGTH_LONG).show();
    }

    public static void regError(String errorMessage) {
        // Implementar aquí el registro de errores arrojados por la aplicación
        Log.d("Contrans-App", errorMessage);
    }
}