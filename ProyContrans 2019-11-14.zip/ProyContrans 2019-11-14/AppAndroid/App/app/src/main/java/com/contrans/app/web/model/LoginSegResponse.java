package com.contrans.app.web.model;

/**
 * Created by carlo on 11/11/2017.
 * -- http://www.jsonschema2pojo.org/
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
//import org.apache.commons.lang.builder.ToStringBuilder;

public class LoginSegResponse {

    @SerializedName("Msj")
    @Expose
    private String msj;
    @SerializedName("UsuaCodigo")
    @Expose
    private String usuaCodigo;
    @SerializedName("UsuaNombres")
    @Expose
    private String usuaNombres;
    @SerializedName("EntiCodigo")
    @Expose
    private String entiCodigo;
    @SerializedName("EntiNombre")
    @Expose
    private String entiNombre;
    @SerializedName("Token")
    @Expose
    private String token;

    public String getMsj() {
        return msj;
    }

    public void setMsj(String msj) {
        this.msj = msj;
    }

    public String getUsuaCodigo() {
        return usuaCodigo;
    }

    public void setUsuaCodigo(String usuaCodigo) {
        this.usuaCodigo = usuaCodigo;
    }

    public String getUsuaNombres() {
        return usuaNombres;
    }

    public void setUsuaNombres(String usuaNombres) {
        this.usuaNombres = usuaNombres;
    }

    public String getEntiCodigo() {
        return entiCodigo;
    }

    public void setEntiCodigo(String entiCodigo) {
        this.entiCodigo = entiCodigo;
    }

    public String getEntiNombre() {
        return entiNombre;
    }

    public void setEntiNombre(String entiNombre) {
        this.entiNombre = entiNombre;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        // return new ToStringBuilder(this).append("msj", msj).append("usuaCodigo", usuaCodigo).append("usuaNombres", usuaNombres).append("entiCodigo", entiCodigo).append("entiNombre", entiNombre).append("token", token).toString();
        StringBuilder sb = new StringBuilder();
        sb.append(" msj: " + msj)
                .append(", usuaCodigo: " + usuaCodigo)
                .append(", usuaNombres: " + usuaNombres)
                .append(", entiCodigo: " + entiCodigo)
                .append(", entiNombre: " + entiNombre)
                .append(", token: " + token);

        return sb.toString();
    }

}
