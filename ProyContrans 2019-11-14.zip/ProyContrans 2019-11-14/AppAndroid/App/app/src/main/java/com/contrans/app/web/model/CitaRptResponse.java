package com.contrans.app.web.model;

/**
 * Created by carlo on 11/11/2017.
 * -- http://www.jsonschema2pojo.org/
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;
//import org.apache.commons.lang.builder.ToStringBuilder;

public class CitaRptResponse {

    @SerializedName("Data")
    private List<Cita> citas;

    public List<Cita> getCitas() {
        return citas;
    }

    public class Cita {

        @SerializedName("Cita")
        @Expose
        private String nroCita;
//    @SerializedName("Fecha")
//    @Expose
//    private String fecha;
//    @SerializedName("Nombre")
//    @Expose
//    private String nombre;
//    @SerializedName("Reprog")
//    @Expose
//    private String reprog;
//
    public String getNroCita() {
        return nroCita;
    }

    public void setNroCita(String nroCita) {
        this.nroCita = nroCita;
    }
//
//    public String getFecha() {
//        return fecha;
//    }
//
//    public void setFecha(String fecha) {
//        this.fecha = fecha;
//    }
//
//    public String getNombre() {
//        return nombre;
//    }
//
//    public void setNombre(String nombre) {
//        this.nombre = nombre;
//    }
//
//    public String getReprog() {
//        return reprog;
//    }
//
//    public void setReprog(String reprog) {
//        this.reprog = reprog;
//    }
//
//
//    @Override
//    public String toString() {
//        // return new ToStringBuilder(this).append("msj", msj).append("usuaCodigo", usuaCodigo).append("usuaNombres", usuaNombres).append("entiCodigo", entiCodigo).append("entiNombre", entiNombre).append("token", token).toString();
//        StringBuilder sb = new StringBuilder();
//        sb.append(" nroCita: " + nroCita)
//                .append(", fecha: " + fecha)
//                .append(", nombre: " + nombre)
//                .append(", reprog: " + reprog);
//
//        return sb.toString();
//    }

    }
}


