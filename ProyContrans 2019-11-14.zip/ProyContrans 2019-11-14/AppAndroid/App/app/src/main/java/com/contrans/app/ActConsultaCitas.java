package com.contrans.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.contrans.app.Util.ActBase;
import com.contrans.app.Util.Util;
import com.contrans.app.web.api.MetodosWeb;
import com.contrans.app.web.model.CitaRptResponse;
import com.contrans.app.web.model.LoginSegResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.Response;

public class ActConsultaCitas extends ActBase {

    private EditText inputNroCita;

    private String token;
    private String nroCita;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_consulta_citas);

        iniciarViewObjects();
        iniciarCampos();
        iniciarEventos();

        LinearLayout item = (LinearLayout)findViewById(R.id.viewListaCitas);
        View child = getLayoutInflater().inflate(R.layout.item_cita, null);
        item.addView(child);

        child = getLayoutInflater().inflate(R.layout.item_cita, null);
        item.addView(child);

        child = getLayoutInflater().inflate(R.layout.item_cita, null);
        item.addView(child);

        child = getLayoutInflater().inflate(R.layout.item_cita, null);
        item.addView(child);

        child = getLayoutInflater().inflate(R.layout.item_cita, null);
        item.addView(child);

        child = getLayoutInflater().inflate(R.layout.item_cita, null);
        item.addView(child);

        child = getLayoutInflater().inflate(R.layout.item_cita, null);
        item.addView(child);
/*
        View listaCitas = (ScrollView) findViewById(R.id.viewListaCitas);
        LayoutInflater  inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View viewCita = (View) inflater.inflate(R.layout.item_cita, null);
        listaCitas.addView(viewCita);
        /*TextView textview1 = (TextView) view.findViewById(R.id.textview1);
        EditText editview1 = (EditText) view.findViewById(R.id.editview1);
        EditText editview2= (EditText) view.findViewById(R.id.editview2);


        viewCita = (View) inflater.inflate(R.layout.item_cita, null);
        listaCitas.addView(viewCita);
*/
        /*viewCita = (View) inflater.inflate(R.layout.item_cita, null);
        listaCitas.addView(viewCita);

        viewCita = (View) inflater.inflate(R.layout.item_cita, null);
        listaCitas.addView(viewCita);

        viewCita = (View) inflater.inflate(R.layout.item_cita, null);
        listaCitas.addView(viewCita);

        viewCita = (View) inflater.inflate(R.layout.item_cita, null);
        listaCitas.addView(viewCita);
        */
    }

    void iniciarViewObjects(){
        inputNroCita = (EditText) findViewById(R.id.input_nro_cita);
    }
    void iniciarCampos(){
        token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6ImphbHZhcmFkbyIsIm5iZiI6MTU3MzY2MzUwNiwiZXhwIjoxNTczNjY1MzA2LCJpYXQiOjE1NzM2NjM1MDYsImlzcyI6Imh0dHBzOi8vMTAuOTMuNS4xNTI6ODA4MCIsImF1ZCI6Imh0dHBzOi8vMTAuOTMuNS4xNTI6ODA4MCJ9.GIWATaYUly3SmEiN23E6m_OoUGnpvydLKcRLe4Eukvg";
        token = "abc";
        nroCita = inputNroCita.getText().toString();
    }
    void iniciarEventos(){

        ImageView btnConsultar = (ImageView) findViewById(R.id.btn_consultar);
        btnConsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if(validarPreviaConsulta()){
                        MetodosWeb restapiContrans = getRetrofitContrans().create(MetodosWeb.class);

                        Call call = restapiContrans.consultaCitas(token, nroCita);

                        call.enqueue(new retrofit2.Callback() {
                            @Override
                            public void onResponse(Call call, Response response) {
                                if (response.body() != null) {
                                    CitaRptResponse listaCitas = (CitaRptResponse)response.body();

                                    //CitaRptResponse[] loginSegResponse = (CitaRptResponse[])response.body();

//                                    if(loginSegResponse.getMsj().toUpperCase().equals("OK")){
//                                        // Autenticación Correcta, vamos hacia la pantalla principal
//                                        Intent intent = new Intent(_ActividadActual, ActPrincipal.class);
//                                        /*intent.putExtra("modo_view", "_REG_");
//                                        intent.putExtra("celular", tv.getText().toString());
//                                        */
//                                        startActivity(intent);
//                                        finish();
//                                    }else{
//                                        // La autenticación ha encontrado un error
//                                        Util.mostrarMensaje(_ActividadActual, loginSegResponse.getMsj());
//                                    }

                                }else{
                                    Util.mostrarMensaje(_ActividadActual, getString(R.string.msg_app_101));
                                }
                            }
                            @Override
                            public void onFailure(Call call, Throwable t) {
                                Util.mostrarMensaje(_ActividadActual, getString(R.string.msg_app_102));
                                Util.regError(t.getMessage());
                            }
                        });
                    }
                } catch (Exception e) {
                    Util.mostrarMensaje(_ActividadActual, "(1001) " + getString(R.string.msg_app_102));
                    Util.regError(e.getMessage());

                    e.printStackTrace();
                    Log.d("Contrans-App", e.getMessage());
                    //Console.d("App-Debug", e.printStackTrace());
                }
            }
        });

    }

    private boolean validarPreviaConsulta(){

        nroCita = inputNroCita.getText().toString();

        return true;
    }

}
