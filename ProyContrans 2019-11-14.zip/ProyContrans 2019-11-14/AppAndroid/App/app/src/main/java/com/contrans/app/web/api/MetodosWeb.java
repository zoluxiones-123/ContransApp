package com.contrans.app.web.api;

/**
 * Created by carlo on 11/11/2017.
 * -- http://www.jsonschema2pojo.org/
 */
import com.contrans.app.web.model.CitaRptResponse;
import com.contrans.app.web.model.LoginSegResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface MetodosWeb {
    /*
    Get request to fetch city weather.Takes in two parameter-city name and API key.
    */
    @POST("/ContransAPI/api/loginSeg")
    @FormUrlEncoded
    Call<LoginSegResponse> login(
            @Field("User") String user
            , @Field("Password") String password
            , @Field("Ip") String ip
            , @Field("Hostname") String hostname
            , @Field("App") String app);

    @POST("/ContransAPI/api/citaRpt")
    @FormUrlEncoded
    Call<CitaRptResponse> consultaCitas(
            @Field("Token") String token
            , @Field("Cita") String cita);

//    @POST("/ContransAPI/api/citaRpt")
//    @FormUrlEncoded
//    void consultaCitas(
//            @Field("Token") String token
//            , @Field("Cita") String cita, Callback<CitaRptResponse> response);
}
