package com.contrans.app.Util;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by carlo on 08/11/2017.
 */

public class WebServiceInfo extends AppCompatActivity {

    String nameSpace = "";
    String baseUrl = "";

    public String getBaseUrl() {
        return this.baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getNameSpace() {
        return this.nameSpace;
    }

    public void setNameSpace(String nameSpace) {
        this.nameSpace = nameSpace;
    }

    public String getAbsoluteUrl(String relativeUrl) {
        return this.baseUrl + relativeUrl;
    }

}